/*
 * mm-implicit.c - an empty malloc package
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 *
 * @id : 201702897 
 * @name : 조해창
 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "mm.h"
#include "memlib.h"

/* If you want debugging output, use the following macro.  When you hand
 * in, remove the #define DEBUG line. */
#define DEBUG
#ifdef DEBUG
# define dbg_printf(...) printf(__VA_ARGS__)
#else
# define dbg_printf(...)
#endif


/* do not change the following! */
#ifdef DRIVER
/* create aliases for driver tests */
#define malloc mm_malloc
#define free mm_free
#define realloc mm_realloc
#define calloc mm_calloc
#endif /* def DRIVER */

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8

/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(p) (((size_t)(p) + (ALIGNMENT-1)) & ~0x7)

#define WSIZE 4
#define DSIZE 8
#define CHUNKSIZE (1 << 12)
#define OVERHEAD 8
#define MAX(x, y) ((x) > (y) ? (x) : (y))
#define PACK(size, alloc) ((size) | (alloc))
#define GET(p) (*(unsigned int *)(p))
#define PUT(p, val) (*(unsigned int *)(p) = (val))
#define GET_SIZE(p) (GET(p) & ~0x7)
#define GET_ALLOC(p) (GET(p) & 0x1)
#define HDRP(bp) ((char *)(bp) - WSIZE)
#define FTRP(bp) ((char*)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)
#define NEXT_BLKP(bp) ((void *)(bp) + GET_SIZE(HDRP(bp)))
#define PREV_BLKP(bp) ((void *)(bp) - GET_SIZE(HDRP(bp) - WSIZE))

static void *extend_heap(size_t words);
static void *find_fit(size_t size);
static void *coalesce(void *bp);
static void place(void *bp, size_t asize);

static char *heap_listp;
static char *last_bp;
/*
 * Initialize: return -1 on error, 0 on success.
 */
int mm_init(void) {
	// 초기 16bytes 크기의 empty heap 생성
	if ( (heap_listp = mem_sbrk(4 * WSIZE)) == (void*)-1 ) return -1;
	PUT(heap_listp, 0);  // 정렬을 위해서 의미없는 값 삽입
	PUT(heap_listp + (1*WSIZE), PACK(OVERHEAD, 1));  // prologue header
	PUT(heap_listp + (2*WSIZE), PACK(OVERHEAD, 1));  // prologue footer
	PUT(heap_listp + (3*WSIZE), PACK(0, 1));  // epilogue header

	heap_listp += DSIZE;
	last_bp = heap_listp;

	if ( extend_heap(CHUNKSIZE/WSIZE) == NULL ) return -1;
    return 0;
}

/*
 * malloc
 */
void *malloc (size_t size) {
	size_t asize;  // Adjusted block size
    size_t extendsize;  // Amount to extend heap if no fit
    char *bp;

    if (size <= 0) return NULL;

	// 할당할 사이즈를 인접한 8의배수로 조정한다.
    asize = DSIZE* ( (size + (DSIZE)+ (DSIZE-1)) / DSIZE );

    if ((bp = find_fit(asize)) != NULL){
		/*
		 * find_fit을 호출하여 적절한 가용블록을 찾는다.
		 * 찾은 가용블록의 bp와 asize를 인자로 하여 place를 호출한다.
		 */
        place(bp,asize);
        return bp;
    }

	/* 적절한 가용블럭을 찾지 못한경우
	 * asize와 CHUNKSIZE 중 더 큰값만큼 heap공간을 늘려서 블럭을 위치시킨다.
	 */
    extendsize = MAX(asize,CHUNKSIZE);
    if ( (bp=extend_heap(extendsize/WSIZE)) == NULL){
        return NULL;
    }
    place(bp,asize);
    return bp;
}

/*
 * free
 */
void free (void *bp) {
	if ( bp == 0 ) return;

	// free할 블록의 사이즈
	size_t size = GET_SIZE(HDRP(bp));

	// free할 블록의 header, footer의 size, alloc을 초기화한다.
    PUT(HDRP(bp),PACK(size,0));
    PUT(FTRP(bp), PACK(size,0));

	// coaleasce를 호출하여 앞 뒤 가용블록과 결합한다.
    coalesce(bp);
}

/*
 * realloc - you may want to look at mm-naive.c
 */
void *realloc(void *bp, size_t size) {
	if ( size <= 0 ) { 
		// 입력 크기가 0 보다 작거나 같으면 free해준다.
        free(bp);
        return 0;
    }
    if ( bp == NULL ) {
		// bp 가 NULL 이면 입력 사이즈만큼 malloc해준다. 
        return malloc(size);
    }
	// size만큼 malloc 한 주소로 newptr을 초기화한다.
    void *newptr = malloc(size);
    if ( newptr == NULL ) {
        return 0;
    }

	// 이전 블록의 정보를 복사한다.
    size_t oldsize = GET_SIZE(HDRP(bp));
    if ( size < oldsize ) oldsize = size;
    memcpy(newptr, bp, oldsize);

	// 이전 블록을 free한다.
    free(bp);

    return newptr;
}

/*
 * calloc - you may want to look at mm-naive.c
 * This function is not tested by mdriver, but it is
 * needed to run the traces.
 */
void *calloc (size_t nmemb, size_t size) {
   size_t bytes = nmemb * size;
   void *newptr;

   newptr = malloc(bytes);
   memset(newptr, 0, bytes);

   return newptr;
}


/*
 * Return whether the pointer is in the heap.
 * May be useful for debugging.
 */
static int in_heap(const void *p) {
    return p < mem_heap_hi() && p >= mem_heap_lo();
}

/*
 * Return whether the pointer is aligned.
 * May be useful for debugging.
 */
static int aligned(const void *p) {
    return (size_t)ALIGN(p) == (size_t)p;
}

/*
 * mm_checkheap
 */
void mm_checkheap(int verbose) {
}

static void *extend_heap(size_t words) {
	char *bp;
	size_t size;
	// words를 짝수로 변환한다.	
	size = (words%2) ? (words+1) * WSIZE : words * WSIZE;
	
	// 힙 사이즈 늘리기를 성공하면 bp에 이전 mem_brk 저장
	if ( (long)(bp = mem_sbrk(size)) == -1 ) return NULL;

	// header, footer에 size 정보 초기화
	PUT(HDRP(bp), PACK(size, 0));
	PUT(FTRP(bp), PACK(size, 0));
	PUT(HDRP(NEXT_BLKP(bp)), PACK(0, 1));

	return coalesce(bp);
}

/*
 * coalesce
 */
static void *coalesce(void *bp){
	// 이전 블록의 가용여부
    size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp)));
	// 다음 블록의 가용여부
    size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
	// 현재 블록의 크기
    size_t size =  GET_SIZE(HDRP(bp));

	/*
	 * case 1: 이전, 다음 블록 모두 비가용인 경우
	 * 블록을 병합하지 않고 bp 반환
	 */
    if (prev_alloc && next_alloc){
        return bp;
    }
	/*
	 * case 2: 이전 블록은 비가용, 다음 블록은 가용인 경우
	 * 다음 블록과 병합한 뒤 bp 반환
	 */
    else if (prev_alloc && !next_alloc){
        size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
        PUT(HDRP(bp),PACK(size,0));
        PUT(FTRP(bp), PACK(size,0));
    }
	/*
	 * case 3: 이전 블록은 가용, 다음 블록은 비가용인 경우
	 * 이전 블록과 병합한 뒤 bp 반환
	 */
    else if(!prev_alloc && next_alloc){
        size+= GET_SIZE(HDRP(PREV_BLKP(bp))); 
        PUT(FTRP(bp), PACK(size,0));
        PUT(HDRP(PREV_BLKP(bp)), PACK(size,0));
        bp = PREV_BLKP(bp);
    }
	/*
	 * case 4: 이전, 다음 블록 모두 가용인 경우
	 * 이전, 다음 블록과 모두 병합한 뒤 bp 반환
	 */
    else {
        size+= GET_SIZE(HDRP(PREV_BLKP(bp))) + GET_SIZE(FTRP(NEXT_BLKP(bp)));
        PUT(HDRP(PREV_BLKP(bp)), PACK(size,0));
        PUT(FTRP(NEXT_BLKP(bp)), PACK(size,0));
        bp = PREV_BLKP(bp);
    }
	// next fit 을 위해 last_bp를 초기화된 bp로 초기화한다.
	last_bp = bp;
    return bp;
}

/*
 * find_fit using first fit
 */
//static void *find_fit(size_t asize){
//	// first fit
//	void *bp;
//
//	/* bp는 heap_listp (prologue footer) 에서 부터 epilogue header 까지 
//	 * 블럭 단위로 이동한다.
//	 */
//	for(bp = heap_listp; GET_SIZE(HDRP(bp)) > 0; bp = NEXT_BLKP(bp)){
//		if ( !GET_ALLOC(HDRP(bp)) && (asize <= GET_SIZE(HDRP(bp)))) {
//			/* 해당 블럭이 가용블럭이고, 블럭의 크기가 asize보다 작다면
//			 * 해당 블럭의 bp 를 반환한다.
//			 */
//			return bp;
//		}
//	}
//	// 알맞은 블럭을 찾지 못했다면 NULL을 반환한다.
//    return NULL;
//}

/*
 * find_fit using next fit
 */
static void *find_fit(size_t asize){
	// next fit
	void *bp;
	/*
	 * bp는 last_bp부터 epilogue header 까지
	 * 블록 단위로 이동한다.
	 */
	for(bp = last_bp; GET_SIZE(HDRP(bp)) > 0; bp = NEXT_BLKP(bp)){
		if ( !GET_ALLOC(HDRP(bp)) && (asize <= GET_SIZE(HDRP(bp))) ) {
			/* 할당 가능한 블록이 fit 되었다면 
			 * last_bp를 초기화하고 해당 블록의 bp 를 반환한다.
			 */
			last_bp = bp;
			return bp;
		}
	}

	/*
	 * 만약 last_bp부터 탐색해서 알맞은 블록을 찾지 못했다면
	 * first fit 방법과 동일하게 last_bp 전까지 탐색한다.
	 */
	for(bp = heap_listp; bp < last_bp; bp = NEXT_BLKP(bp)){
		if ( !GET_ALLOC(HDRP(bp)) && (asize <= GET_SIZE(HDRP(bp))) ) {
			last_bp = bp;
			return bp;
		}
	}
	return NULL;
}
/*
 * place
 */
static void place(void *bp, size_t asize){
	// bp는 find fit으로 찾은 bp, asize는 할당할 크기이다.

	// csize를 주어진 bp의 크기로 초기화한다.
    size_t csize = GET_SIZE(HDRP(bp));

    // 블럭 쪼개기의 최소 크기를 8bytes로한다. header(4), footer(4), payload(0)
    if ( (csize-asize) >= (DSIZE)){
        PUT(HDRP(bp), PACK(asize,1)); // header의 size, alloc 정보 초기화
        PUT(FTRP(bp), PACK(asize,1)); // footer의 위치가 바뀜과 동시에 size, alloc
									  // 정보 초기화
        bp = NEXT_BLKP(bp);		      // bp를 다음 블록의 위치로 초기화
        PUT(HDRP(bp), PACK(csize-asize,0)); // header의 size, alloc 정보 초기화
        PUT(FTRP(bp), PACK(csize-asize,0)); // footer의 size, alloc 정보 초기화
    }
    else{
		/*
		 * 남은 공간이 가용 공간으로써 충분한 공간이 아니라면
		 * 해당 bp를 csize 크기의 비가용 블록으로 초기화한다.
		 */
        PUT(HDRP(bp), PACK(csize,1));
        PUT(FTRP(bp), PACK(csize,1));
    }
}

