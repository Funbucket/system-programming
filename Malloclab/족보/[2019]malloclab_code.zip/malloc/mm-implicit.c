/*
 * mm-implicit.c - an empty malloc package
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 *
 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "mm.h"
#include "memlib.h"

/* If you want debugging output, use the following macro.  When you hand
 * in, remove the #define DEBUG line. */
#define DEBUG
#ifdef DEBUG
# define dbg_printf(...) printf(__VA_ARGS__)
#else
# define dbg_printf(...)
#endif


/* do not change the following! */
#ifdef DRIVER
/* create aliases for driver tests */
#define malloc mm_malloc
#define free mm_free
#define realloc mm_realloc
#define calloc mm_calloc
#endif /* def DRIVER */

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8

/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(p) (((size_t)(p) + (ALIGNMENT-1)) & ~0x7)
/*매크로 정의*/
#define WSIZE 4 //word크기 정렬
#define DSIZE 8  // double word //크기결정
#define CHUNKSIZE (1<<12) //초기 heap의 크기를 설정한다
#define OVERHEAD 8 //헤더와 푸터의 크기를 합친 크기
#define MAX(x,y) ((x)>(y) ? (x) : (y)) //둘 중에 더 큰값 찾기
#define PACK(size, alloc) ((size) | (alloc)) //size와 alloc 값 묶기
#define GET(p) (*(unsigned int*)(p)) //p의 word 크기 값
#define PUT(p,val) (*(unsigned int*)(p)=(val)) //p가 가리키는 word크기의val값
#define GET_SIZE(p) (GET(p) & ~0x7) //p가 가리키는 곳에서 하위 3bit를 버린다= blck size
#define GET_ALLOC(p) (GET(p)&0x1) //p가 가리키는 곳에서 하위 1비트 읽기(할당 여부)
#define HDRP(bp) ((char*)(bp)-WSIZE) //bp의 헤더 주소
#define FTRP(bp) ((char*)(bp)+GET_SIZE(HDRP(bp))-DSIZE) //bp의 푸터 주소
#define NEXT_BLKP(bp) ((char*)(bp) + GET_SIZE(((char*)(bp)-WSIZE)))//BP를 이용하여 다음 블럭 주소를 계산한다
#define PREV_BLKP(bp) ((char*)(bp)-GET_SIZE(((char*)(bp)-DSIZE)))
//bp를 이용하여 다음 block 주소를 계산한다
/*
 * Initialize: return -1 on error, 0 on success.
 */
void* heap_listp;
void* last;

//어느곳에 할당할지 찾는 함수
static void * find_fit(size_t asize) {
	
	//초기값을 last로 설정해준다
	void *first = last;
	//힙의 끝부분
	void *end = mem_heap_hi();
	//힙의 끝부분에 도달할때까지 계속 반복한다
	while(first <end) {
		//조건 : 비할당이거나, 사이즈가 같거나 큰 블록이라면
		if(!GET_ALLOC(HDRP(first)) && (GET_SIZE(HDRP(first))>=asize)) {
			//위치를 찾았다며 리턴을 해준다
			return first;
		}
		//아니라면 블록을 이동한다
		first = NEXT_BLKP(first);
	}
	return NULL;
}
//조건에 맞는 곳을 찾았다면 할당해주기
static void place(void *bp, size_t asize) {

	size_t size = GET_SIZE(HDRP(bp));
	//bp가 가리키는 블록의 사이즈 받기
	//외부 단편화를 막이 위해서
	if((size-asize)>=(2*DSIZE)){
		//size-asize한 것이 >=16이면 블럭을 나누고 할당하기 시작
		PUT(HDRP(bp), PACK(asize,1)); //asize만큼 할당, 할당됨을 알리는 1세팅하기
		PUT(FTRP(bp), PACK(asize,1));

		bp = NEXT_BLKP(bp); //bp는 다음 bp를 가리킨다. 헤더와 푸터 세팅이 완료되어서

		PUT(HDRP(bp), PACK(size-asize,0));//size-asize만큼의 크기, 할당함 세팅
		PUT(FTRP(bp), PACK(size-asize,0));

	} else {
		PUT(HDRP(bp), PACK(size,1)); //bp 헤더에 size 크기와 할당함 1 세팅
		PUT(FTRP(bp), PACK(size,1));
	}

}

//빈 공간을 합쳐주는 역할을 하는 함수
static void *coalesce(void *bp){

	size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp)));

	//이전 블럭이 할당 되었는지 안 되었는지 0, NO 1 = Yes
	size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
	//다음 블럭 할당 여부
	size_t size = GET_SIZE(HDRP(bp));
	//현재 블럭의 크기
	/*case 1 : 
	  이전 블럭, 다음 블럭 최하위 비트 둘다 1인경우 -> 할당됨
	  블럭 병합 없이 bp를 return한다.
	 */
	if(prev_alloc && next_alloc) {
		return bp;
	}

	/*case 2 : 
	 이전 블럭 최하위 비트가 1이고(할당) 다음 블럭 최하위 비트가 0인 경우(비할당)
	 다음 블럭과 병합한 뒤 bp return
	 */
	else if(prev_alloc && !next_alloc) {
		size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
		PUT(HDRP(bp), PACK(size, 0));
		PUT(FTRP(bp), PACK(size, 0));
		//PACK은 alloc에 결합하는 함수이다 size만큼 OR연산을 하는 것
		//PUT은 이 포인터 위치에다가 이 값을 넣겠다, 하고 쓰는 함수
		// HDRP(헤더 포인터) , FTRP(footer 포인터)

	/*case 3 : 이전 블럭 최하위 bit가 0이고,(비할당)
	 다음 블럭의 최하위 비트가 1인 경우(할당) 이전 블럭과 병합한 뒤 새로운 bp retrun*/	
	} else if(!prev_alloc && next_alloc) {
		size += GET_SIZE(HDRP(PREV_BLKP(bp)));
		//bp가 가리키는 블록의 사이즈 + 이전 블록의 사이즈
		PUT(FTRP(bp), PACK(size, 0));
		//bp의 푸터에 합친 사이즈와 할당이 안됐으므로 0을 넣음
		PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
		bp = PREV_BLKP(bp);
		//bp는 bp의 이전 블록을 가리키게 된다.
	}
	/*case 4 : 이전 블럭 최하위 bit가 0(비할당)
	 다음 블럭 최하위가 0인 경우 이전, 현재, 다음 블럭 모두 병합 후 새로운 bp return */

	else {
		//이전, 현재, 다음 블록을 다 합친다
		size += GET_SIZE(HDRP(PREV_BLKP(bp))) + GET_SIZE(FTRP(NEXT_BLKP(bp)));
		//이전 블록의 헤더와 푸터에 size할당이 안되었으므로 0 삽입하기
		PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
		PUT(FTRP(PREV_BLKP(bp)), PACK(size, 0));
		
		bp = PREV_BLKP(bp);
		//bp는 이전 블로을 가리키게 한다.
	}
	last = bp; //마지막으로 탐색한 곳 저장하기
	return bp;//리턴하rl
	//병합된 블럭의 주소 bp return 
}

//힙의 크기를 확장해준다
static void *extend_heap(size_t words) {
	
	char *bp;
	size_t size;
	//words를 짝수로 변환
	size = (words % 2) ? (words+1) * WSIZE : words *WSIZE;
	
	//mem_sbrk()함수의 size가 -1이면 확장을 실패했다는 뜻이다
	//long으로 형변환을 해서 실패 성공 여부를 알 수 있다
	if((long) (bp = mem_sbrk(size)) == -1)
		return NULL;
	//확장에 성공한 경우
	PUT(HDRP(bp), PACK(size,0)); //확장 블록 헤더에 사이즈와 할당 여부 저장
	PUT(FTRP(bp), PACK(size,0));
	
	PUT(HDRP(NEXT_BLKP(bp)), PACK(0,1)); //다음 블록 해더를 0과 1로 초기화 시킴
	//이 코드가 지금 안됨 위에거

	return coalesce((void*)bp);
}


int mm_init(void) {
	
	//초기에 empty heap을 생성한다
    if((heap_listp = mem_sbrk(4*WSIZE)) == NULL)
		return -1; //heap_listp= 새로 생성되는 heap 영역의 시작이다
	
	PUT(heap_listp, 0); //의미없는 값 삽입
	PUT(heap_listp + WSIZE, PACK(OVERHEAD, 1)); //prologue header
	PUT(heap_listp + DSIZE, PACK(OVERHEAD, 1));
	PUT(heap_listp + WSIZE + DSIZE, PACK(0,1)); //에필로그 헤더
	heap_listp += DSIZE;

	last = heap_listp;

	//CHUNKSIZE 바이트의 free 블럭만큼 empty head를 확정한다
	//생성된 empty heap을 free block으로 확장한다
	//WSIZE align으로 되어있지 않으면 에러
	/*
	 * 맨 처음에 힙을 생성하는 함수로, 메모리 공간을 설정한다. 메모리 공간은 CHUNKSIZE
	 * 메모리 공간에 다수의 블럭을 생성하여 사용
	 * 초기 블럭은 16바이트의 크기를 가짐
	 * heap_listp의 위치를 header와 footer사이로 이동시킨다
	 * 메모리 공간만큼 heap을 확장한다.
	 * 
	 */
	if((extend_heap(CHUNKSIZE/WSIZE)) == NULL)
		return -1;

	return 0;
}

/*
 * malloc
 */
void *malloc (size_t size) {
    size_t asize;
	size_t extendsize;
	char *bp;
	

	if(size == 0) //할당 사이즈가 0이면 할당할 것이 없음
		return NULL;

	if(size <= DSIZE) {
		asize = 2*DSIZE; //할당희망 사이즈가 8보다 작거나 같으면 16만큼 넣기
	} else {
	//8보다 클 경우 메모리 사이즈를 정해서 저장
		asize = DSIZE * ((size+(DSIZE) + (DSIZE-1))/DSIZE);
	} 

	if((bp = find_fit(asize)) != NULL) {
		place(bp, asize);
		return bp;
	}
	extendsize = MAX(asize, CHUNKSIZE);
	//만약 할당 공간을 찾지 못하면 둘중에 큰 값을 찾는다
	if((bp = extend_heap(extendsize/WSIZE)) == NULL) {
		return NULL;
	}
	place(bp, asize);
	//새롭게 커진 위치에 할당해준다.
	last = NEXT_BLKP(bp);
	//bp의 다음 블록을 가리키게 한다
	return bp;


}

/*
 * free
 */
/*
void mm_free(void *bp) {
	
	if(bp == 0) return; //잘못된 free 요청인 경우 함수를 종료한다.이전 프로시져로 리턴
	size_t size = GET_SIZE(HDRP(bp)); //bp의 헤더에서 block size를 읽어온다
	//실제로 데이터를 지우는 것이 아니라
	//header와 footer의 최하위 1bit(1, 할당된 상태)만을 수정한다
	PUT(HDRP(bp), PACK(size, 0));
	PUT(FTRP(bp), PACK(size, 0)); //bp의 footer에 block size와 alloc = 0을 저장한다

	coalesce(bp); //주위에 빈 블록이 있을 시 병합한다

}
*/
void free (void *ptr) {
    //할당된 블록을 free시키기
	if(ptr == 0) return; //할당이 되어있지 않을 경우

	size_t size = GET_SIZE(HDRP(ptr));//헤더의 사이즈를 저장한다
	PUT(HDRP(ptr), PACK(size,0)); //할당 -> 가용
	PUT(FTRP(ptr), PACK(size,0)); //할당 -> 가용

	coalesce(ptr);
	//할당안된 블록과 지금 free시킨 블록을 합치려고 함수 실행
}

/*
 * realloc - you may want to look at mm-naive.c
 */
void *realloc(void *oldptr, size_t size) {
    size_t oldsize;
	void *newptr;

	if(size == 0) {
		free(oldptr);
		return 0;
	}	

	if(oldptr == NULL) {
		return malloc(size);
	}
	newptr = malloc(size);
	if(!newptr) {
		return 0;
	}

	oldsize = GET_SIZE(HDRP(oldptr));
	//헤더가 가리키는 곳에서 사이즈를 읽는 것
	if(size < oldsize) oldsize = size;
	memcpy(newptr, oldptr, oldsize);

	free(oldptr);
	return newptr;
}

/*
 * calloc - you may want to look at mm-naive.c
 * This function is not tested by mdriver, but it is
 * needed to run the traces.
 */
void *calloc (size_t nmemb, size_t size) {
    size_t bytes = nmemb * size;
	void *newptr;

	newptr = malloc(bytes);
	memset(newptr, 0, bytes);
	
	return newptr;
}

/*
 * Return whether the pointer is in the heap.
 * May be useful for debugging.
 */
static int in_heap(const void *p) {
    return p < mem_heap_hi() && p >= mem_heap_lo();
}

/*
 * Return whether the pointer is aligned.
 * May be useful for debugging.
 */
static int aligned(const void *p) {
    return (size_t)ALIGN(p) == (size_t)p;
}

/*
 * mm_checkheap
 */
void mm_checkheap(int verbose) {
}
